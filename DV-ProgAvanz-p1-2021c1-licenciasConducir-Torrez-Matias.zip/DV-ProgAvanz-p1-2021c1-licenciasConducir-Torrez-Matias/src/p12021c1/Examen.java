
package p12021c1;

import java.util.ArrayList;


/**
 *
 * @author Charly Cimino
 * Aprendé más Java en mi canal: https://www.youtube.com/c/CharlyCimino
 * Encontrá más código en mi repo de GitHub: https://github.com/CharlyCimino
 */
public class Examen implements Evaluable{
    // ¿Atributos?...
    private String ID;
    private ArrayList<Circuito> circuitos;

    public Examen(String ID) {
        this.ID = ID;
        circuitos = new ArrayList<>();
    }
    
    public void agregarCircuito(Circuito c) {
        this.circuitos.add(c);
    }
    // Agregar lo que consideres que falte...
    
    public int cantidadCircuitos(){
        return this.circuitos.size();
    }

    @Override
    public boolean estaAprobado() {
        int contador = 0;
        for (Circuito c : circuitos) {
            if(c.estaAprobado()){
                contador++;
            }
        }
        return contador == cantidadCircuitos();
    }
    
    public int cantidadFaltasCometidas(){
        int faltasCometidas = 0;
        for (Circuito c : circuitos) {
            if(c instanceof CircuitoDeDestreza){
                faltasCometidas += ((CircuitoDeDestreza) c).getCantFaltasCometidas();
            }
        }
        return faltasCometidas;
    }
    
}
