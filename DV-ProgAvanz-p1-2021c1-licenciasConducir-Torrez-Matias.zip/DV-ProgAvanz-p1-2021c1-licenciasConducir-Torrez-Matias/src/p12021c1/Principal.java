package p12021c1;

/**
 *
 * @author Charly Cimino Aprendé más Java en mi canal:
 * https://www.youtube.com/c/CharlyCimino Encontrá más código en mi repo de
 * GitHub: https://github.com/CharlyCimino
 */
public class Principal {

    /*
        NO OLVIDES RENOMBRAR EL PROYECTO: DV-ProgAvanz-p1-2021c1-licenciasConducir-TUAPELLIDO-TUNOMBRE
     */
    public static void main(String[] args) {

        /*
            NO TOCAR MÉTODO MAIN NI CARGA DE EXÁMENES
            Si todo está bien, al ejecutar debe mostrar los resultados esperados.
         */
        ////////////////////////////////// NO TOCAR ///////////////////////////////////
        Sede s = new Sede();
        ////////////////////////////////// NO TOCAR ///////////////////////////////////
        cargarExamenes(s);
        ////////////////////////////////// NO TOCAR ///////////////////////////////////
        System.out.println("Porcentaje de aprobados");
        System.out.println(s.porcentajeDeAprobados() + "%\n");
        ////////////////////////////////// NO TOCAR ///////////////////////////////////
        System.out.println("Faltas totales cometidas");
        System.out.println(s.totalDeFaltasCometidas() + " faltas");

    }

    ////////////////////////////////// NO TOCAR ///////////////////////////////////
    private static void cargarExamenes(Sede s) {
        Examen e1 = new Examen("EX01");
        Examen e2 = new Examen("EX02");
        Examen e3 = new Examen("EX03");
        Examen e4 = new Examen("EX04");
        Examen e5 = new Examen("EX05");
        ////////////////////////////////// NO TOCAR ///////////////////////////////////
        e1.agregarCircuito(new CircuitoDeDestreza("0/0/00", 2));
        e1.agregarCircuito(new CircuitoDeDestreza("0/0/00", 1));
        e1.agregarCircuito(new CircuitoDeVelocidad("0/0/00", 97));
        ////////////////////////////////// NO TOCAR ///////////////////////////////////
        e2.agregarCircuito(new CircuitoDeVelocidad("0/0/00", 90));
        e2.agregarCircuito(new CircuitoDeDestreza("0/0/00", 2));
        e2.agregarCircuito(new CircuitoDeDestreza("0/0/00", 0));
        e2.agregarCircuito(new CircuitoDeVelocidad("0/0/00", 86));
        ////////////////////////////////// NO TOCAR ///////////////////////////////////
        e3.agregarCircuito(new CircuitoDeDestreza("0/0/00", 0));
        e3.agregarCircuito(new CircuitoDeVelocidad("0/0/00", 110));
        e3.agregarCircuito(new CircuitoDeDestreza("0/0/00", 0));
        ////////////////////////////////// NO TOCAR ///////////////////////////////////
        e4.agregarCircuito(new CircuitoDeDestreza("0/0/00", 0));
        e4.agregarCircuito(new CircuitoDeDestreza("0/0/00", 0));
        e4.agregarCircuito(new CircuitoDeVelocidad("0/0/00", 88));
        e4.agregarCircuito(new CircuitoDeVelocidad("0/0/00", 89));
        e4.agregarCircuito(new CircuitoDeVelocidad("0/0/00", 84));
        ////////////////////////////////// NO TOCAR /////////w//////////////////////////
        e5.agregarCircuito(new CircuitoDeVelocidad("0/0/00", 92));
        e5.agregarCircuito(new CircuitoDeDestreza("0/0/00", 1));
        e5.agregarCircuito(new CircuitoDeVelocidad("0/0/00", 93));
        e5.agregarCircuito(new CircuitoDeDestreza("0/0/00", 3));
        ////////////////////////////////// NO TOCAR ///////////////////////////////////
        s.agregarExamen(e1);
        s.agregarExamen(e2);
        s.agregarExamen(e3);
        s.agregarExamen(e4);
        s.agregarExamen(e5);
    }

}
