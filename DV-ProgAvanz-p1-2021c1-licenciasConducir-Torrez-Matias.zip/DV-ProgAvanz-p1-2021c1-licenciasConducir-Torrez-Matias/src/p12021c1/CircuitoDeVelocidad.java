/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p12021c1;

/**
 *
 * @author Matias
 */
public class CircuitoDeVelocidad extends Circuito {
    public final static int TIEMPO_APROBADO = 90;
    private int tiempoEnSegundoRealizado;

    public CircuitoDeVelocidad( String fecha,int tiempoEnSegundoRealizado) {
        super(fecha);
        this.tiempoEnSegundoRealizado = tiempoEnSegundoRealizado;
    }

    @Override
    public boolean estaAprobado() {
        return tiempoEnSegundoRealizado <= TIEMPO_APROBADO;
    }
    
    
    
}
