/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p12021c1;

/**
 *
 * @author Matias
 */
public abstract class Circuito implements Evaluable{
    
    private String fecha;

    public Circuito(String fecha) {
        this.fecha = fecha;
    }
    
    
    
}
