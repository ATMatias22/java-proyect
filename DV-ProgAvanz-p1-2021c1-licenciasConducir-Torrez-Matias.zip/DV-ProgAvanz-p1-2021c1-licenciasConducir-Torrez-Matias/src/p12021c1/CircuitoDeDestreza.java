/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p12021c1;

/**
 *
 * @author Matias
 */
public class CircuitoDeDestreza extends Circuito{
    public final static int FALTAS_PERDONADAS = 2;
    private int cantFaltasCometidas;

    public CircuitoDeDestreza(String fecha,int cantFaltasCometidas) {
        super(fecha);
        this.cantFaltasCometidas = cantFaltasCometidas;
    }

    public int getCantFaltasCometidas() {
        return cantFaltasCometidas;
    }
    
    @Override
    public boolean estaAprobado() {
    
        return cantFaltasCometidas <= FALTAS_PERDONADAS;
    }

    
    
    
    
}
