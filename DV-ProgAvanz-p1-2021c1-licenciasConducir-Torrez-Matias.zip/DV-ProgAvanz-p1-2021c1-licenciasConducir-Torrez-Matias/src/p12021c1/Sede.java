
package p12021c1;

import java.util.ArrayList;

/**
 *
 * @author Charly Cimino
 * Aprendé más Java en mi canal: https://www.youtube.com/c/CharlyCimino
 * Encontrá más código en mi repo de GitHub: https://github.com/CharlyCimino
 */
public class Sede {
    // ¿Atributos?...
    private ArrayList<Examen> examenes;

    public Sede() {
        this.examenes = new ArrayList<>();
    }
    
    public void agregarExamen(Examen e) {
        this.examenes.add(e);
    }
    
    public int cantidadExamenes(){
        return this.examenes.size();
    }
    
    public double porcentajeDeAprobados() {
        // Implementar...
        int aprobados = 0;
        for (Examen e : examenes) {
            if(e.estaAprobado()){
                aprobados++;
            }
        }
        double porcentajeAprobados = (aprobados*100)/cantidadExamenes();
        
        return cantidadExamenes() > 0 ? porcentajeAprobados : 0; // Debe devolver el valor que corresponda
    }
    
    public int totalDeFaltasCometidas() {
        // Implementar...
        int faltasTotales = 0;
        for (Examen e : examenes) {
           faltasTotales += e.cantidadFaltasCometidas();
        }
        
        return faltasTotales; // Debe devolver el valor que corresponda
    }
    
    // Agregar lo que consideres que falte...
    
    
}
